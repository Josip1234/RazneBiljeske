<!DOCTYPE html>
<html>
<head>
    <title>Osnove HTML - linkovi</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
<h2>Linkovi (poveznice)</h2>
<p><a href="liste.html">Liste</a></p>
<p><a href="https://www.w3schools.com/" target="_blank" title="Stranica za učenje">W3schools</a></p>
<p><a href="tablice.html"><img src="smiley.png" width="64px" height="64px"></a></p>
<p><a href="osnove.html#cetvrti">Osnove</a></p>
</body>
</html>