<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Osnove HTML - zadatak za izradu</title>
    <style>
        /* za h1 sam stavio neki random font da ne bude nekakav klasični */
        h1{
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
        /* stavio sam naslov u centar */
        #container{
            margin: 0 auto;
            text-align: center;
        }
        /* bilo koji tekst sa klasom txt će biti poravnat na lijevu stranu */
        .txt{
          text-align: left;
        }
        /* tablica sa input elementima bi trebala također ići u centar */
        table{
            margin: 0px auto;
        }
        /* staviti ću općeniti border na body , dodao sam unutarnji razmak do 80% kako bih prikazao granice glavnog kontejnera za obrazac */
        body{
            border-style: ridge;
            padding-bottom: 80%;
            
        }

        /* box-sizing omogućuje da padding i border budu jednaki sa totalnom širinom i visinom drugog elementa
          u osovm slučaju padding i border je podjednak sa veličinom table data elementa
        */
       input {
  width: 100%;
height: 100%;
  box-sizing: border-box;
}
/* css selektorima možemo odabirati na primjer i tip input forme kao što je select i checkbox */
select{
    width: 100%;
    height: auto;
    box-sizing: border-box;
    background-color: antiquewhite;
}
/* proširi veličinu tablice na 50 posto containera */
table{
    width: 50%;
    height: auto;
}
/* prošiti veličinu textarea na 98 posto */
 textarea{
    width: 98%;
    height: auto;
 }
 /* postavi boju na button makni border sa buttona color white boja fonta */
input[type=submit]{
      background-color: #04AA6D;
    border: none;
    color: white;
}
input[type=reset]{
    background-color: red;
    border: none;
    color: white;
}
/* prilikom pozicioniranja miša na buttone postavi ih u sivo */
input[type=submit]:hover, input[type=reset]:hover{
      background-color: grey;
    border: none;
    color: white;
}
/* stil za smanjenje veličine kružića ili kvadratića od radio buttona */
.reduce_size_of_circle_square{
width:2%
}


    </style>
</head>
<body>
    <!-- formu i elemente forme ću postaviti u div kontejner kojeg ću centirati preko css-a 
    za elemente polja ćemo staviti i validaciju required , polja ne bi smjela biti prazna, 
    radi sigurnosti ćemo staviti i atribut autocomplete off ne bismo željeli da netko drugi vidi naše unesene podatke 
    osim nas samih
    staviti ćemi i placeholdere kao primjer recimo ime Pero prezime perić
    -->
    <div id="container">
    <h1>Obrazac za prijavu kandidata na posao</h1>
    <form>
        <!-- kao layout ću koristiti tablicu  -->
       <table border="1">
          <tbody>
            <tr>
                <td class="txt">Ime:</td>
                <td><input type="text" name="ime" required autocomplete="off" placeholder="Josip"></td>
            </tr>
            <tr>
                <td class="txt">Prezime:</td>
                <td><input type="text" name="prezime" required autocomplete="off" placeholder="Bošnjak"></td>
            </tr>
            <tr>
                <td class="txt">Upišite lozinku za korisnički račun:</td>
                <td><input type="password" name="lozinka" required autocomplete="off" placeholder="123456test"></td>
            </tr>
                <tr>
                <td class="txt">Potvrdite lozinku za korisnički račun:</td>
                <td><input type="password" name="lozinka" required autocomplete="off" placeholder="123456test"></td>
            </tr>
            <!--koristim polje email jer već sadržava potrebnu validaciju za unos email-am moguće je napraviti i custom validaciju email-a 
            bez obzira što već postoji i ugrađena-->
            <tr>
                <td class="txt">Unesite vašu email adresu:</td>
                <td><input type="email" name="email" required autocomplete="off" placeholder="jbosnjak3@gmail.com"></td>
            </tr>
            <tr> 
                <!-- kao broj ću staviti number, za tel oznaku će biti potrebna posebna validacija 
                s obzirom da je moguće putem strelice unositi brojeve, stavio sam atribut min
                da se ne bi mogla unjeti negativna razlika 
                -->
                <td class="txt">Unesite broj telefona:</td>
                <td><input type="number" name="brojtelefona" min="0" required autocomplete="off" placeholder="0985644123"></td>
            </tr>
            <tr>
                <!-- za defaultnu vrijednost nema potrebe 
                 za required je moguće samo na jednom radio button definirati da mora biti bar odabran
                 to vrijedi za čitavu grupu jer svi imaju istu name vrijednost  
                -->
                <td class="txt">Odaberite spol:</td>
                <td><input type="radio" name="spol" id="m" required class="reduce_size_of_circle_square">Muški <input type="radio" name="spol" id="z" class="reduce_size_of_circle_square">Ženski</td>
            </tr>
            <tr>
                <!-- kako bi uskladio veličinu drugih polja
                 css-om je moguće isto napraviti razmak primjerice imamo nekakav paragraf p 
                 stavimo p u css i iskoristimo white-space: pre ili druga varijanta 
                 postavimo span kod teksta primjerice <span>Muški></span> u css-u definiramo 
                 p span display:block
                 required za checkbox ne podržava isto kao i za radio buttone
                 potrebno je malo više programiranja da se to napravi za checkbox
                 trenutno nema potrebe za tim
                -->
                <td class="txt">Odaberite vještine:</td>
                <td><input type="checkbox" name="vjestina"  value="HTML" class="reduce_size_of_circle_square">HTML 
                 <input type="checkbox" name="vjestina"  value="CSS" class="reduce_size_of_circle_square">CSS  
                 <input type="checkbox" name="vjestina"  value="PHP" class="reduce_size_of_circle_square">PHP 
                 <input type="checkbox" name="vjestina"  value="JS" class="reduce_size_of_circle_square">JavaScript
               
                </td>
            </tr>
            <tr>
                <td class="txt">Odaberite poziciju:</td>
                <td><select name="pozicija">
                    <option value="BckDev">Backend Developer</option>
                    <option value="FrntDev">Frontend Developer</option>
                    <option value="QATst">QA Tester</option>
                </select></td>
            </tr>
            <tr>
                <td class="txt">Motivacijsko pismo:</td>
                <td>
                    <textarea name="motivacijsko" rows="5" cols="20" required autocomplete="off"></textarea>
                </td>
            </tr>
            <tr>
                <td class="txt">Učitajte životopis:</td>
                <td><input type="file" name="zivotopis" required>
                </td>
            </tr>
            <!--stavljamo value jer korisnik ne upisuje ovaj podatak-->
            <input type="hidden" name="idobrasca" value="job-application-2025">
            <tr>
                <td>
                    <input type="submit" value="Pošalji prijavu">
                </td>
                <td>
                    <input type="reset" value="Poništi unos">
                </td>
            </tr>
          </tbody>
       </table>
    </form>
    </div>
</body>
</html>