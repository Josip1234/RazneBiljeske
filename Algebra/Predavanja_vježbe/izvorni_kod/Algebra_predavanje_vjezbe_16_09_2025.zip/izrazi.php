<?php 
$ime="Pero";
echo $ime;

$broj=10;
echo "<br>Broj:".$broj;

$oznaka=2;
$rezultat=$broj*$oznaka;
echo "<h2>Rezultat je $rezultat </h2>";
//die("Dogodila se greška!");
//exit();
print "<h3>Pozdrav svima</h3>";
printf("Ime je : %s, Oznaka : %d", $ime, $oznaka);



?>