<!DOCTYPE html>
<html>
<head>
    <title>Osnove HTML - liste</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
<h2>Sređene liste - programski jezici</h2>
<ol>
    <li>PHP</li>
    <li>Java</li>
    <li>C#</li>
</ol>
<h2>Nesređene liste - editori</h2>
<ul>
    <li>VS Code</li>
    <li>Notepad++</li>
    <li>Ultra Edit</li>
</ul>
<h2>Definicijske liste</h2>
<dl>
  <dt>Kava</dt>
  <dd>Omiljeni napitak</dd>
    <dt>Mlijeko</dt>
    <dd>Neizostavni produkt za kavu</dd>
</dl>
</body>
</html>