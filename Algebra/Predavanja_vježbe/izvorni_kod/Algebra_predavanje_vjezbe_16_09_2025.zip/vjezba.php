<!DOCTYPE html>
<html>
<head>
    <title>Osnove HTML - vjezba</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
<h2>Obrazac za vježbu</h2>
<form>
    <table border="1">
        <tr>
            <td>Ime:</td>
            <td><input type="text" name="ime"></td>
        </tr>
        <tr>
            <td>Prezime:</td>
            <td><input type="text" name="prezime"></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>Država:</td>
            <td><select name="drzava">
                <option value="HR">Hrvatska</option>
                <option value="SI">Slovenija</option>
            </select></td>
        </tr>
        <tr>
            <td>Spol:</td>
            <td><input type="radio" name="gender" id="male">Muški
            <input type="radio" name="gender" id="female">Ženski</td>
        </tr>
        <tr>
            <td>Zanima me:</td>
           <td>
            <input type="checkbox" name="zanimanje" value="pli">Plivanje
              <input type="checkbox" name="zanimanje" value="penj">Penjanje
                <input type="checkbox" name="zanimanje" value="prog">Programiranje

           </td>
         </tr>
         <tr>
            <td>
                Učitajte životopis:
            </td>
            <td><input type="file" name="datoteka"></td>
         </tr>
         <tr>
            <td colspan="2">
                <input type="submit" value="Posalji">
            </td>
         </tr>
    </table>
</form>
</body>
</html>