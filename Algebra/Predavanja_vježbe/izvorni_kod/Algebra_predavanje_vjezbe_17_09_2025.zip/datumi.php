<!DOCTYPE html>
<html>

<head>
    <title>Datumi u PHP-u</title>
</head>

<body>
    <?php
    $datum = Date("d.m.Y");
    echo "<br>Datum je: " . $datum;

    $datum_dr_format = Date("Y-m-d");
    echo "<br>Datum je: " . $datum_dr_format;

    $dd = date("d");
    $mm = date("m");
    $gg = date("Y");
    echo "<br>Dan:" . $dd;
    echo "<br>Mjesec:" . $mm;
    echo "<br>Godina:" . $gg;

    $praznik_rada = "01.05.2024";
    echo "<br>Praznik rada: " . $praznik_rada;
    //želim ovaj datum konvertirati za sql
    $datumzasql = date("Y-m-d", strtotime($praznik_rada));
    echo "<br> Za SQL:" . $datumzasql;
    //https://www.w3schools.com/php/func_date_date.asp

    $vrijeme = date("H:i:s");
    echo "<br>Vrijeme je: " . $vrijeme;


    $sat = date("H");
    echo "<br>Sat: " . $sat;
    echo "<br>Sekunde:" . strtotime($praznik_rada);

    $datumvrijeme = date("d.m.Y H:i:s");
    echo "<br> Datum vrijeme(timestamp):" . $datumvrijeme;

    $unos = "24.07.2023 15:32:45"; //datum unosa
    $unossql = date("Y-m-d H:i:s", strtotime($unos));
    echo "<br> Unos sql je:" . $unossql;

    $datum1 = "15.09.2025 17:00:00";
    $datum2 = "15.09.2025 17:02:00";
    $razlika = strtotime($datum2) - strtotime($datum1);
    echo "<br>Razlika vremena:" . $razlika;
    $datum2 = "15.09.2025 17:02:30";
    $razlika = strtotime($datum2) - strtotime($datum1);
    echo "<br>Razlika vremena:" . $razlika; //u sekundama podjeliti sa 60 za minute

    $trenutnidan = date("l"); //lowercase današnji dat
    echo "<br>Trenutni dan:" . $trenutnidan;

    //dodavanje mjeseca na trenutni datum
    $dodajmjesec = date("d.m.Y", strtotime("+1 month", strtotime(date("d.m.Y"))));
    echo "<br>Dodan mjesec:" . $dodajmjesec;

    $nekidatum = "22.03.2022";
    $dodajmjesec = date("d.m.Y", strtotime("+1 month", strtotime($nekidatum)));
    echo "<br>Dodan mjesec:" . $dodajmjesec;
    $dodajmjesec = date("d.m.Y", strtotime("+2 month", strtotime($nekidatum)));
    echo "<br>Dodan mjesec:" . $dodajmjesec;
    $dodajmjesec = date("d.m.Y", strtotime("-2 month", strtotime($nekidatum)));
    echo "<br>Dodan mjesec:" . $dodajmjesec;

    


    ?>
</body>

</html>