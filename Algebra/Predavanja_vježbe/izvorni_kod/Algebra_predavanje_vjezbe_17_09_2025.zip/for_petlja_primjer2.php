<!DOCTYPE html>
<html>
    <head>
        <title>For petlja primjer 2</title>
    </head>
    <body>
          <?php 

        echo "<table border='1'>";
        $limit=5;
        for($m=1;$m<=$limit;$m++){
            echo "<tr>";
            for($n=1;$n<=$limit;$n++){
                echo "<td>".($m*$n)."</td>";
            }
            echo "</tr>";
        }
        echo "</table>";

?>
    </body>
</html> 