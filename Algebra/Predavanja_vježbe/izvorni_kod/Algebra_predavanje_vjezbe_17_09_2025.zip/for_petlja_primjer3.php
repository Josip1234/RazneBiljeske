<!DOCTYPE html>
<html>
    <head>
        <title>Php primjer 3</title>
    </head>
    <body>
         <?php 
          
          $broj=rand(3,8);
          $faktorijeli=1;
          for ($temp=$broj; $temp>1; $temp--) { 
               $faktorijeli*=$temp;
               echo "<br>iteracija: $faktorijeli=$faktorijeli*$temp";
               
          }
          echo "<br>Faktorijeli broja:".$broj." Iznose:".$faktorijeli;
    
?>
    </body>
</html> 