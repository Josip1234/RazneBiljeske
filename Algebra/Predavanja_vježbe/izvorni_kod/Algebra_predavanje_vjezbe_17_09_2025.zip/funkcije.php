<!DOCTYPE html>
<html>

<head>
    <title>Funkcije</title>
</head>

<body>
    <?php
    Ispis();
    echo "<h1>Funkcije</h1>";
    echo "<h2>Osnovna funkcija</h2>";
    function Ispis(): void
    {
        echo "<br>Ja sam funkcija";
    }
    Ispis();
    Ispis();
    echo "<p>Ispis funkcije 10 puta</p>";
    for ($i = 1; $i <= 10; $i++) {
        Ispis();
        echo "- " . $i . "Put";
    }

    echo "<h2>Funkcija sa lokalnom varijablom</h2>";
    function lokalna()
    {
        $a = 10;
        $b = 5;
        $c = $a + $b;
        echo "<br>Rezultat je: " . $c;
        $d = sqrt($c);
        echo "<br>Korijen od $c: " . $d;
    }
    lokalna();
    echo "<h2>Funkcija sa globalnom varijablom</h2>";
    $kolicina = 100;
    echo "<br>Količina:" . $kolicina;
    function ukupno()
    {
        global $kolicina;
        $cijena = 15;
        $ukupno = $kolicina * $cijena;
        echo "<br>Ukupno: " . $ukupno;
        $kolicina *= 2;
    }
    ukupno();
    echo "<br>Količina:" . $kolicina;

    function brojac()
    {
        static $brojac = 0;
        $brojac++;
        echo "<br>Funkcija Brojac pozvana" . $brojac . " puta!";
    }
    brojac();
    brojac();
    brojac();

    echo "<h2>Funkcije sa parametrima</h2>";
    $x = 25;
    function Korijen($x)
    {
        $korijen = sqrt($x);
        echo "<br>Korijen broja $x je:" . $korijen;
    }
    Korijen($x);
    Korijen(36);
    Korijen($x = 100);

    function Kvadrat($a = 10)
    {
        $kvadrat = pow($a, 2);
        echo "<br>Kvadrat broja $a je:" . $kvadrat;
    }
    Kvadrat(15);
    echo "<p>Primjer</p>";

    for ($i = 0; $i <= 10; $i++) {
        $broj = rand(10, 100);
        if ($broj % 2 == 0) {
            Korijen($broj);
        } else {
            Kvadrat($broj);
        }
    }

    echo "<h2>Funkcije sa parametrima -2</h2>";
    function ZbrojiBrojeve($x1, $x2)
    {
        $zbroj = $x1 + $x2;
        echo "<br> Zbroj brojeva $x1 i $x2 je:" . $zbroj;
    }
    ZbrojiBrojeve(100, 200);

    echo "<p>Primjer</p>";
    for ($broj = 0; $broj < 10; $broj++) {
        $broj1 = rand(10, 99);
        $broj2 = rand(10, 99);
        ZbrojiBrojeve($broj1, $broj2);
    }

    echo "<h2>Funkcija koja vraća vrijednost</h2>";
    function ParnostBroja($br)
    {
        if ($br % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }
    echo "<br>Broj 5 je paran:" . (int)ParnostBroja(5); //false neće nikad ispisati castamo u integer
    echo "<br>Broj 10 je paran:" . (int)ParnostBroja(10);

    function SlozenostBroja($brojka)
    {
        $djeljitelji = 0;
        for ($j = 1; $j <= $brojka; $j++) {
            if ($brojka % $j == 0) {
                $djeljitelji++;
            }
        }
        return $djeljitelji>2 ? " - složen":" - prost"; 
    }
    echo "<br>Složenost broja 10:".SlozenostBroja(10);
    echo "<br>Složenost broja 5:".SlozenostBroja(5);
    ?>
</body>

</html>