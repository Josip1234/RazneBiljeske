<!DOCTYPE html>
<html>
    <head>
        <title>Funkcije primjer 1</title>
    </head>
    <body>
<?php 
   function VratiDanZaDatum($datum){
    $day=date("l",strtotime($datum));
      switch ($day) {
        case "Monday":
            $danCRO = "Ponedjeljak";
            break;
        case "Tuesday":
            $danCRO = "Utorak";
            break;
        case "Wednesday":
            $danCRO = "Srijeda";
            break;
        case "Thursday":
            $danCRO = "Četvrtak";
            break;
        case "Friday":
            $danCRO = "Petak";
            break;
        case "Saturday":
            $danCRO = "Subota";
            break;
        default:
            $danCRO = "Nedjalja";
    }
    return $danCRO;
   }
    
   echo "<br>Dan za datum 15.04.2019 je bio:".VratiDanZaDatum("15.04.2019");
   $dan_neradni=VratiDanZaDatum("01.05.2025");
   echo "<br>Dan neradni:".$dan_neradni;

   function GenerirajSlucajniDatum($pocetnaGod){
        $gg=rand($pocetnaGod,date("Y"));
        $mm=rand(1,12);
        if($mm==2){
            if($gg%4==0){
                $dd=rand(1,29);
            }else{
                $dd=rand(1,28);
            }
        }elseif($mm=1 || $mm=3 || $mm=5 || $mm=7 || $mm=8 ||$mm=10 || $mm=12){
            $dd=rand(1,31);
        }else{
            $dd=rand(1,30);
        }
        if($mm<=9){
            $mm="0".$mm;
        }
        if($dd<=9){
            $dd="0".$dd;
        }
        return $dd.".".$mm.".".$gg;
   }
   $slucDatum=GenerirajSlucajniDatum(2000);
   echo "<br>Slucajni datum:".$slucDatum;
   echo "<br>Dan za datum:".GenerirajSlucajniDatum(2000)." je bio: ". VratiDanZaDatum(GenerirajSlucajniDatum(2000));
    
   for($i=0;$i<10;$i++){
    $slucajni_datum=rand(1991,2025);
    $generirani_datum=GenerirajSlucajniDatum($slucajni_datum);
    $dan_za_datum=VratiDanZaDatum($generirani_datum);
    echo "<br>".$generirani_datum." ".$dan_za_datum."";
   }

   

?>
    </body>
</html> 