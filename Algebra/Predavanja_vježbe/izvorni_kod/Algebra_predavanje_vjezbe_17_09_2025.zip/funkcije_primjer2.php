<!DOCTYPE html>
<html>
    <head>
        <title>Funkcije primjer 2</title>
    </head>
    <body>
<?php 
      function Aritmetika($br1,$br2,$operacija){
        echo "<br>Broj1:".$br1;
          echo "<br>Broj2:".$br2;
            echo "<br>Operacija:".$operacija;
            switch ($operacija) {
                case "z":
                    $rezultat=$br1+$br2;
                    break;
                case "o":
                    $rezultat=$br1-$br2;
                    break;
                case "m":
                    $rezultat=$br1*$br2;
                    break;
                case "d":
                     if($br2!=0){
                        $rezultat=$br1/$br2;
                     }else{
                        $rezultat="Pokušaj djeljenja sa nulom";
                     }
                     break;
                case "mod":
                        if($br2!=0){
                        $rezultat=$br1%$br2;
                     }else{
                        $rezultat="Pokušaj djeljenja sa nulom";
                     }
                    break;
                default:
                    $rezultat="Pogrešna operacija!";
                
            }
            return $rezultat;
      }
      echo "<br>Aritmetika: ".Aritmetika(100,200,"z");
      echo "<br>Aritmetika: ".Aritmetika(100,0,"d");
      echo "<br>Aritmetika: ".Aritmetika(100,0,"t");
?>
    </body>
</html> 