<!DOCTYPE html>
<html>
    <head>
        <title>Stringovi</title>
    </head>
    <body>
<?php 
$recenica="Danas je Srijeda, sredina tjedna.";
echo "<br>Rečenica: ".$recenica;
$duljina=strlen($recenica);
echo "<br>Duljina:".$duljina;
echo "<br>Prvi znak:".substr($recenica,0,1);
echo "<br>Treći znak:".substr($recenica,2,1);
echo "<br>Sedmi i osmi znak:".substr($recenica,6,2);
echo "<br>Zadnji znak:".substr($recenica,-1);

echo "Ispis svih znakova:";
for ($i=0; $i <strlen($recenica) ; $i++) { 
    $znak=substr($recenica,$i,1);
    echo "<br>Znak:".$znak;
}
echo "<br>Ispisati koliko puta se pojavilo slovo a";
$brojac=0;
for ($i=0; $i <strlen($recenica) ; $i++) { 
    $znak=substr($recenica,$i,1);
    //echo "<br>".$znak;
    if($znak=='a'){
        $brojac++;
    }
}
echo "<br>Znak a se pojavio ".$brojac." Puta";
$broj_slova=substr_count($recenica,"a");
echo "<br>Broj slova: ".$broj_slova;

$pozicija_zarez=strpos($recenica,",");
echo "<br>Pozicija:".$pozicija_zarez;

$izdvojeni_string=substr($recenica,$pozicija_zarez+1,strlen($recenica));
echo "<br>Izdvojeni string:".$izdvojeni_string;




?>
    </body>
</html> 