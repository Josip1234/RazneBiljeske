<!DOCTYPE html>
<html>
    <head>
        <title>Testiranje debuga</title>
    </head>
    <body>
<?php

$a = 5;
$b = 10;
$c = $a + $b;
echo $c;

?>

    </body>
</html> 