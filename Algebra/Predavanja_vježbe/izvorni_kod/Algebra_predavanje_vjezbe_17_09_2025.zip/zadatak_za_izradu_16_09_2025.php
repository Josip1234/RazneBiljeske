<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Osnove php - zadatak za izradu</title>
    <style>
            #container{
            margin: 0 auto;
            text-align: center;
        }
            table {
            width: 60%;
            border-collapse: collapse;
            border-style: groove;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            font-size: 200%;
            margin: 0px auto;
            
            
        }
        thead{
            background-color:#5B9BD5;
        }
           th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
            font-weight: normal;
            border-style: groove;
            border-color: black;
        }
        .prosle{
            background-color: #70AD47;
        }
        .nisu_prosle{
            background-color: #D9D9D9;
        }
       .newtable{
        margin-top: 5%;
       }
    </style>
</head>
<body>
    <div id="container">
        <h2>Tablica treba izgledati ovako:</h2>
            <table>
        <thead>
            <tr>
                <th>Životinja</th>
                <th>Bodovi</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
           <tr class="nisu_prosle">
            <td>Životinja br.1</td>
            <td>10</td>
            <td>Pad</td>
           </tr>
           <tr class="nisu_prosle">
            <td>Životinja br.2</td>
            <td>5</td>
            <td>Pad</td>
           </tr>
           <tr class="prosle">
            <td>Životinja br.3</td>
            <td>17</td>
            <td>Prolaz</td>
           </tr>
           <tr>
            <td>.....................</td>
            <td>.....................</td>
            <td>.....................</td>
           </tr>
            <tr class="nisu_prosle">
            <td>Životinja br.10</td>
            <td>13</td>
            <td>Pad</td>
           </tr>
        </tbody>
    </table>
    <table class="newtable">
        <thead>
            <tr>
               
                <th>Životinja</th>
                <th>Bodovi</th>
                <th>Status</th>
             
            </tr>
            <?php 
             $zivotinja="Životinja br.";
             $broj=1;
             $bodovnagranicazaprolaz=15;
             $brojbodova=0;
             $prolaz="";
             $klasa="";
             $ukupanbrojzivotinjakojesuprosle=0;
             while($broj<=10){
                $brojbodova=rand(5,20);
                if($brojbodova>15){
                    $prolaz="Prolaz";
                    $klasa="prosle";
                    $ukupanbrojzivotinjakojesuprosle++;
                }else{
                    $prolaz="Pad";
                    $klasa="nisu_prosle";
                }
            ?>
            <tr class="<?php echo $klasa;  ?>">
                <td><?php  echo $zivotinja.$broj;   ?></td>
                <td><?php  echo $brojbodova;  ?></td>
                <td><?php  echo  $prolaz;  ?></td>
            </tr>
            <?php 
             $broj++;
             }

            ?>
        </thead>
    </table>
    <h2>Ukupan broj životinja koje su prošle iznosi: <?php echo $ukupanbrojzivotinjakojesuprosle; ?></h2>
    </div>

</body>
</html>