<!DOCTYPE html>
<html>
    <head>
        <title>Asocijativni nizovi</title>
    </head>
    <body>
      <?php 
     include_once("sve_funkcije.php");

     $imena=array("Pero"=>45,"Dado"=>15,"Miro"=>50,"Ana"=>36,"Cico"=>29);
     ispis_niza($imena);

     echo "<br>Dado ima ".$imena["Dado"]."godina";
     $imena["Bobo"]=32;
     ispis_niza($imena);

     $key1=key($imena);
     echo "<br>Prvi ključ: ".$key1;
     $val1=current($imena);
     echo "<br>Prva vrijednost:".$val1;

     $maksime=key($imena);
     $maxgod=current($imena);
     foreach ($imena as $ime => $god) {
        if($god>$maxgod){
            $maxgod=$god;
            $maksime=$ime;
        }
     }
   echo "<br>Najstariji: ".$maksime.", godine: ".$maxgod;
   $dani=array("Monday"=>"Ponedjeljak","Tuesday"=>"Utorak","Wednesday"=>"Srijeda","Thursday"=>"Četvrtak","Friday"=>"Petak","Saturday"=>"Subota","Sunday"=>"Nedjelja");
   $currDay=date("l");
   echo "<br>Danas je:".$dani[$currDay];
   $osoba = [
    "ime"=>"Pero",
    "prezime"=>"Perić",
    "godine"=>25,
    "placa"=>2578.56
   ];
   ispis_niza($osoba);

   echo "<p>Primjer</p>";

   $auti["BMW"]="Pero";
$auti["Audi"]="Mate";
$auti["Kia"]="Ana";
$auti["Golf"]="Pero";
$auti["Mercedes"]="Miro";
$auti["Opel"]="Pero";
$auti["Honda"]="Mate";
$auti["Toyota"]="Marko";
$auti["Fiat"]="Bobo";
$auti["Ford"]="Cico";
$auti["Jetta"]="Pero";
$auti["Jaguar"]="Bobo";
$auti["Dacia"]="Robo";
$auti["Renol"]="Zlatko";
$auti["Suzuki"]="Pero";
$auti["Hyundai"]="Bobo";
$auti["Zastava"]="Miro"; 

ispis_niza($auti);

$vlasnici=array();
foreach ($auti as $key1 => $val1) {
    $brojac=0;
    foreach ($auti as $key2 => $val2) {
        if($val1==$val2){
            $brojac++;
        }
    }
    $vlasnici[$val1]=$brojac;
}
foreach ($vlasnici as $vlasnik => $brauta) {
    echo "<br>Vlasnik:".$vlasnik."posjeduje".$brauta.".";
}
arsort($vlasnici);
ispis_niza($vlasnici);
ksort($vlasnici);
ispis_niza($vlasnici);
krsort($vlasnici);
ispis_niza($vlasnici);

?>
    </body>
</html> 