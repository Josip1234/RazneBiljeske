<!DOCTYPE html>
<html>
    <head>
        <title>For primjer</title>
    </head>
    <body>
<?php

for ($i=1; $i<=30 ; $i++) {
    echo "<br>Broj:".$i;
    $djeljitelji=0;
    for ($j=1; $j <= $i ; $j++) { 
        if($i%$j==0){
            $djeljitelji++;
        }
    }
/*
if($djeljitelji>2){
    echo "- složen";
}else{
    echo "- prost";
}*/
echo $djeljitelji>2 ? " - složen":" - prost"; 
}
?>
    </body>
</html> 