<!DOCTYPE html>
<html>
    <head>
        <title>For petlja primjer 4</title>
    </head>
    <body>
<?php 
$broj_redova=5;
for ($i=1; $i <=$broj_redova ; $i++) { 
    for($j=1;$j<$i;++$j){
        echo $j." ";
    }
    echo "<br>";
}

?>
    </body>
</html> 