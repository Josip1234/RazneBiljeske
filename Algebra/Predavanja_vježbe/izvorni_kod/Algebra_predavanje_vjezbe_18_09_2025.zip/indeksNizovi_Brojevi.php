<!DOCTYPE html>
<html>

<head>
    <title>Php indeksirani nizovi</title>
</head>

<body>

    <?php
    include("sve_funkcije.php");
    $brojevi[0] = 35;
    $brojevi[1] = 22;
    $brojevi[2] = 17;
    $brojevi[3] = 19;
    $brojevi[4] = 29;
    $brojevi[5] = 41;
    $brojevi[6] = 32;
    $brojevi[7] = 27;

    ispis_niza($brojevi);

    $najmanji = $brojevi[0];
    $najveci = $brojevi[0];
    $suma = 0;
    $suma_neparnih_poz = 0;
    $parnih_elemenata = 0;
    foreach ($brojevi as $key => $val) {
        $suma += $val;
        if ($val < $najmanji) {
            $najmanji = $val;
        }
        if ($val > $najveci) {
            $najveci = $val;
        }
        if ($key % 2 == 1) {
            $suma_neparnih_poz += $val;
        }
        if ($val % 2 == 0) {
            $parnih_elemenata++;
        }
    }
    echo "<br>Najmanji element je: " . $najmanji;
    echo "<br>Najveći element je: " . $najveci;
    $prosjek = $suma / count($brojevi);
    echo "<br>Prosjek: " . $prosjek;
    echo "<br>Suma elemenata neparnih pozicija je: " . $suma_neparnih_poz;
    echo "<br>Parnih elemenata u nizu:: " . $parnih_elemenata;

    echo "<p>Sortiranje niza - uzlazno </p>";
    for($i=0;$i<sizeof($brojevi);$i++){

        for($j=$i+1;$j<sizeof($brojevi);$j++){
            $tmp=0;
            if($brojevi[$i]>$brojevi[$j]){
                $tmp=$brojevi[$i];
                $brojevi[$i]=$brojevi[$j];
                $brojevi[$j]=$tmp;
            }
        }
        echo "<br>Broj:".$brojevi[$i];
    } 

      echo "<p>Gotove metode za sortiranje</p>";
      sort($brojevi);
      ispis_niza($brojevi);
      rsort($brojevi);
      ispis_niza($brojevi);
      ksort($brojevi);
      ispis_niza($brojevi);
      krsort($brojevi);
      ispis_niza($brojevi);

      /* 
       zadan je rečenica Moje ime je Davorin Bogović i sve oko mene je crno bijeli svijet.
       potrebno je rečenicu pretvoriti u niz te ispisati svaku vrijednost. U produžetku ispisati 
       koliko je svaka vriejdnost velika (duljina) te ukoliko je veća od 5 ispisati 5
       ili više znakova inače ispisati manje od 5 znakova 
       npr. Davorin  => 7 => 5 i više znakova
      
      
      */
      $recenica="Moje ime je Davorin Bogović i sve oko mene je crno bijeli svijet.";
      $niz=explode(" ",$recenica);
      ispis_niza($niz);
      foreach ($niz as $value) {
         $velicina_vrijednosti=strlen($value);
         if($velicina_vrijednosti>=5){
            $info="5 i vise znakova";
         }else{
            $info="manje od 5 znakova";
         }
         echo "<br>Velicina vrijednosti:".$velicina_vrijednosti;
          echo "<br>:".$val."=>".$velicina_vrijednosti."=>".$info;



      }
      /**
       * potrebno je kreirati indeksirani niz ds 10 brojeva koji se ne smiju ponavljati (u rasponu od 10 do 99)
       * provjeru postojanja duple vrijednosti napraviti pomoću funkcije provjeri duplog koji kao parametre prihvaća niz 
       * i broj koji se provjerava 
       * ako funkcija vrati tru to je oznaka da postoji broj u suprotnom vraća false da ne postoji
       * 
       */
      $brojke=array();
      $brojke[]=55;
      for($m=1;$m<=9;$m++){
        $broj=rand(10,99);
        $ima=provjeriDuplog($brojke,$broj);
        if(!$ima){
            $brojke[]=$broj;
        }else{
            $m--;
        }
      }
      ispis_niza($brojke);

    ?>
</body>

</html>