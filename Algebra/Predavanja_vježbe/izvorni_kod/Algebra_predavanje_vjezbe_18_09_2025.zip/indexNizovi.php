<!DOCTYPE html>
<html>
    <head>
        <title>PHP Indeksirani nizovi </title>
    </head>
    <body>
      <?php 
      include("sve_funkcije.php");
         echo "<p>Kreiranje niza</p>";
         $auto="BMW";
         echo "<br>Auto je:".$auto;

           $auto="Audi";
         echo "<br>Auto je:".$auto;


         $auti=array("BMW","Audi","Kia","Mercedes","Škoda","Opel","Golf");
         //indexi      0     1      2       3         4      5       6
         echo "<br>Ja vozim:".$auti[0];
           echo "<br>Ja vozim:".$auti[5];

           echo "<p>Struktura niza</p>";
           print_r($auti);
           echo "<br>Dump:";
           var_dump($auti);

           $duljina=count($auti);//sizeof($auti)
           echo "<br>Duljina:".$duljina;
           
           echo "<p>Ipsis nza preko for petlje</p>";
           for($a=0;$a<sizeof($auti);$a++){
            echo "<br>Element niza:".$auti[$a];
           }
           $auti[]="Fiat";
           
           echo "<p>Struktura niza</p>";
           print_r($auti);
           array_push($auti,"Hyundai","Citroen");
              echo "<p>Struktura niza</p>";
           print_r($auti);

               echo "<p>Ipsis nza preko for petlje</p>";
           for($a=0;$a<sizeof($auti);$a++){
            echo "<br>Element niza:".$auti[$a];
           }

           //micanje elementa niza
           unset($auti[4]);

                 echo "<p>Struktura niza</p>";
           print_r($auti);

      for($a=0;$a<sizeof($auti);$a++){
              if(array_key_exists($a,$auti)) echo "<br>1.Element niza:".$auti[$a];
                   
           
          }
             
           
           
     
           echo "<p>Ispis niza preko foreach petlje - vrijednosti</p>";
           foreach ($auti as $auto) {
                  echo "<br> Auto je:".$auto;
           }
           $auti[14]="Suzuki";
            foreach ($auti as $auto) {
                  echo "<br> Auto je:".$auto;
           }
         
           foreach ($auti as $poz => $element) {
             echo "<br>Pozicija:".$poz."=>".$element;
           }
          ispis_niza($auti);
          array_push($auti,"Honda");
          ispis_niza($auti);

          $slova=[];
          ispis_niza($slova);
          if(in_array("Opel",$auti)){
            echo "<br>Postoji Opel!";
          }else{
             echo "<br>Ne postoji Opel";
          }

          $izraz="Danas je Četvrtak i lijepo je vrijeme";
          $niz=explode(" ", $izraz);
          ispis_niza($niz);
          $gradovi=array("Zagreb","Split","Rijeka","Osijek","Dubrovnik");
          ispis_niza($gradovi);
          //pretvoriti u teksualni niz
          $gradovi_string=implode("-",$gradovi);
          echo "<br>Gradovi string:".$gradovi_string;
          $indeks=array_search("Osijek",$gradovi);
          echo "<br>Osijek se nalazi na indeksu: ".$indeks;

      ?>
    </body>
</html> 