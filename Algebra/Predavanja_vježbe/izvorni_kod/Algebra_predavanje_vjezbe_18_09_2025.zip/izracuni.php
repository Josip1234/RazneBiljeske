<?php 

function generiraj_ucenika($broj_ucenika){
    $ucenik="Učenik br.";
    $ucenik_sa_brojem=$ucenik.$broj_ucenika;
    return $ucenik_sa_brojem;
}

function generiraj_ocjenu(){
    return rand(1,5);
}
//(2 + 3 + 7 ) / 3 = 12/3 = 4     2,3,7 su vrijednosti 3 je ukupan broj brojeva 
function izracunaj_prosjek_ocjena($ocjena1,$ocjena2,$ocjena3,$ocjena4,$ocjena5){
$ukupan_broj_ocjena=5;
    if(($ocjena1==1)||($ocjena2==1)||($ocjena3==1)||($ocjena4==1)||($ocjena5==1)){
        $prosjek_ocjena=1;
    }else{
        $prosjek_ocjena=($ocjena1+$ocjena2+$ocjena3+$ocjena4+$ocjena5)/$ukupan_broj_ocjena;
    }

return $prosjek_ocjena;
}

function zaokruzi_broj($broj,$broj_decimale=2){
    return round($broj,$broj_decimale);
}
function vrati_uspjeh_za_sljedeci_prosjek($prosjek){
    //uzeo sam i ona granične što ako je prosjek 1.48? 
    //stavio da bude recimo nedovoljan
   $uspjeh="";
   if(($prosjek==1)&&($prosjek<1.5)){
    $uspjeh="nedovoljan";
   }else if (($prosjek>=1.5)&&($prosjek<2.5)) {
    $uspjeh="dovoljan";
   }else if(($prosjek>=2.5)&&($prosjek<3.5)){
     $uspjeh="dobar";
   }else if(($prosjek>=3.5)&&($prosjek<4.5)){
     $uspjeh="vrlo dobar";
   }else{
    $uspjeh="odlican";
   }
   return $uspjeh;
}

?>