<!DOCTYPE html>
<html>

<head>
    <title>Kontrola switch</title>
    <style>
        .crvena {
            color: red;
        }

        .zelena {
            color: green;
        }

        .plava {
            color: blue;
        }

        label {
            display: block;
        }
    </style>
</head>

<body>
    <?php

    //zadana je šifra boje od 1 do 3 
    /* 
       1-crvena
       2-plava
       3-zelena
    potrebno je ispitati vrijednost boje te za dobivenu boju ispisati sljedeće:
    Odabrana je crvena boja! npr za 1
    dodatak: definiratu u css-u tri klase za tri boje pa ih primjeniti ovisno o uvjetu
    tekst ispisatu u labelama sa pripadajućom klasom
    dodatak 2 za slučaj dva ispisati kvadrat boje (2*2)
    */
    $boja = rand(1, 7);
    echo "<br>Boja:" . $boja;
    switch ($boja) {
        case 1:
            $klasa = "crvena";
            echo "<label class=\"$klasa\">Odabrana je crvena boja!</label>";
            break;
        case 2:
            $klasa = "plava";
            echo "<label class=\"$klasa\">Odabrana je plava boja!</label>";
            $kvadrat = $boja * $boja;
            echo "<label>Kvadrat:" . $kvadrat . "<label>";
            break;
        case 3:
            $klasa = "zelena";
            echo "<label class=\"$klasa\">Odabrana je zelena boja!</label>";
            break;
        default:

            echo "<label>Pogrešna boja!</label>";
    }

    $danENG = date("l");
    switch ($danENG) {
        case "Monday":
            $danCRO = "Ponedjeljak";
            break;
        case "Tuesday":
            $danCRO = "Utorak";
            break;
        case "Wednesday":
            $danCRO = "Srijeda";
            break;
        case "Thursday":
            $danCRO = "Četvrtak";
            break;
        case "Friday":
            $danCRO = "Petak";
            break;
        case "Saturday":
            $danCRO = "Subota";
            break;
        default:
            $danCRO = "Nedjalja";
    }
    echo "<br>Dan Cro:" . $danCRO;
    ?>
</body>

</html>