<?php 

include_once("sve_funkcije.php");
echo "<br>Slučajni datum:".GenerirajSlucajniDatum(2010);

  include_once("sve_funkcije.php");
    echo "<br>Aritmetika: ".Aritmetika(100,200,"d");

    echo "<br>Samoglasnici za predator:".VratiBrojSamoglasnika("Predator");

?>