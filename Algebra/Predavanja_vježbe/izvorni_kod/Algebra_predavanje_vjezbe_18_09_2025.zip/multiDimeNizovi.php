<!DOCTYPE html>
<html>
    <head>
        <title>Multidimenzionalni nizovi</title>
        <style>
                    table {
            width: 60%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            font-size: 12px;
            margin-top: 20px
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        } 
        .istekao{
            background-color: red;
        }
        .neparni{
            background-color: green;
        }
        </style>
    </head>
    <body>
      <?php 
require_once("sve_funkcije.php");

$matrica=[
    [1,2,3],
    [4,5,6],
    [7,8,9]
];

foreach ($matrica as $i => $red) {
    foreach ($red as $j => $element) {
        echo "<br>Element ".$element." na poziciji ($i,$j)";
    }
}

echo "<p>Osobe</p>";
$osobe=[
    [
        "ime"=>"Ana",
        "prezime"=>"Anić",
        "godine"=>20,
    ], [
        "ime"=>"Marko",
        "prezime"=>"Marić",
        "godine"=>35,
    ], [
        "ime"=>"Ivana",
        "prezime"=>"Ivić",
        "godine"=>19,
    ]
    ];

    foreach ($osobe as $osoba) {
         echo "<br>Ime: ".$osoba["ime"];
          echo "<br>Prezime: ".$osoba["prezime"];
           echo "<br>Godine: ".$osoba["godine"];
           echo "<hr>";
    }


    echo "<p>Primjer proizvodi</p>";
    $proizvodi=[
        
            ["Sifra"=>101,"Naziv"=>"Kruh","Cijena"=>1.20,"Zaliha"=>100,"RokIstek"=>"25.10.2025"],
            ["Sifra"=>102,"Naziv"=>"Mlijeko","Cijena"=>0.99,"Zaliha"=>50,"RokIstek"=>"18.09.2025"],
            ["Sifra"=>103,"Naziv"=>"Jogurt","Cijena"=>0.80,"Zaliha"=>75,"RokIstek"=>"10.08.2025"],
        ];
    
       $proizvodi[]=[ "Sifra"=>104,"Naziv"=>"Sir","Cijena"=>4.20,"Zaliha"=>199,"RokIstek"=>"31.12.2025"];
      array_push($proizvodi,["Sifra"=>105,"Naziv"=>"Keks","Cijena"=>5.25,"Zaliha"=>300,"RokIstek"=>"12.05.2025"]);

?>
<table>
 <thead>
    <tr>
        <th>
            Sifra
        </th>
        <th>
            Naziv
        </th>
        <th>
            Cijena
        </th>
        <th>
            Zaliha
        </th>
        <th>
            Rok isteka
        </th>
    </tr>
 </thead>
 <tbody>
    <?php 
      foreach ($proizvodi as $pr) {
        $datumistek=strtotime($pr["RokIstek"]);
        if(time()>$datumistek){
            $klasa="istekao";
        }else{
            $klasa="";
        }
        echo "<tr class=\"$klasa\">";
        echo "<td>".$pr["Sifra"]."</td>";
         echo "<td>".$pr["Naziv"]."</td>";
          echo "<td>".$pr["Cijena"]."</td>";
           echo "<td>".$pr["Zaliha"]."</td>";
           echo "<td>".$pr["RokIstek"]."</td>";
        echo "</tr>";
      }
    ?>
 </tbody>
</table>
<?php 
$sifPr=103;
foreach ($proizvodi as &$p) {
    if($p["Sifra"]===103){
        $p["Cijena"]=1.15;
    }
}
unset($p);

?>
<table>
 <thead>
    <tr>
        <th>
            Sifra
        </th>
        <th>
            Naziv
        </th>
        <th>
            Cijena
        </th>
        <th>
            Zaliha
        </th>
            <th>
            Rok isteka
        </th>
    </tr>
 </thead>
 <tbody>
    <?php 
      foreach ($proizvodi as $pr) {
        echo "<tr>";
        echo "<td>".$pr["Sifra"]."</td>";
         echo "<td>".$pr["Naziv"]."</td>";
          echo "<td>".$pr["Cijena"]."</td>";
           echo "<td>".$pr["Zaliha"]."</td>";
           echo "<td>".$pr["RokIstek"]."</td>";
        echo "</tr>";
      }
      //kopirati kod na novi php sa predavanja 

      /**
       * zadan je asocijativni niz sa šiframa i njihovim nazivima te indeksirani niz sa numeričkim vrijednostima
       * potrebno je izdvojiti sve one proizvode čija se šifra poklapa sa vrijednošću u indeksiranom nitu u jedan novi indeksirani 
       * nit i ispisati dobivene vrijednosti
       */
      $sifreProizvodi["101"]="Jabuka";
       $sifreProizvodi["102"]="Kruška";
        $sifreProizvodi["103"]="Ananas";
         $sifreProizvodi["104"]="Banana";
          $sifreProizvodi["105"]="Naranča";

          $numericNiz=array(99,102,105,109,111,120,17);
          foreach ($numericNiz as $val1) {
            foreach ($sifreProizvodi as $key2 => $val2) {
                if($val1==$key2){
                    $novi[]=$val2;
                }
            }
          }
          print_r($novi);
    ?>
 </tbody>
</table>
    </body>
</html> 