<?php 

echo "<p><a href='varijable.php'>Varijable</a></p>";
echo "<p><a href=\"varijable.php\">Varijable</a></p>";
echo '<p><a href=\'varijable.php\'>Varijable</a></p>';
echo '<p><a href="varijable.php">Varijable</a></p>';



?>