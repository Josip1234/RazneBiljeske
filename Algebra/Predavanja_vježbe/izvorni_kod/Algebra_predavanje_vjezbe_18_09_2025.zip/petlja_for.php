<!DOCTYPE html>
<html>
    <head>
        <title>Petlja for</title>
    </head>
    <body>
         <?php
         echo "<p>Ispis brojeva od 1 do 10</p>";
         for ($br=0; $br <=10 ; $br++) { 
            echo "<br>Broj:".$br;
         }
         //negdje je greška
           echo "<p>Ispis brojeva od 20 do 10</p>";
         for ($nn=20; $nn>=10;$nn--) { 
            echo "<br>Broj:".$nn;
            
         }
         echo "<p>Ispis parnih brojeva od 1 do 30</p>";
         for ($x=2; $x<=30 ; $x+=2) { 
            echo "<br>Parni broj:".$x;
         }
          echo "<p>For petlja - prekid  </p>";
         for ($iznos=100; $iznos<=200; $iznos++) { 
             echo "<br>Iznos:".$iznos;
             if($iznos=150){
                break;
             }
         }
         echo "<p>For petlja - ugnježdena</p>";
         for($i=1;$i<=10;$i++){
            echo "<br>Broj:".$i."|";
            for($j=0;$j<$i;$j++){
                echo $j.",";
            }
         }


         ?>
    </body>
</html> 