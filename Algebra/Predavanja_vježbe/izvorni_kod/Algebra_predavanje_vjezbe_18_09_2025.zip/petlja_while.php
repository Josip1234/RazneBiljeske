<!DOCTYPE html>
<html>
    <head>
        <title>Petlja while</title>
    </head>
    <style>
        table {
            width: 60%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            font-size: 12px;
            margin-top: 20px
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        } 
        .parni{
            background-color: red;
        }
        .neparni{
            background-color: green;
        }
    </style>
    <body>
        <?php 
        echo "<p>Primjer 1</p>";
   //potrebno je ispisati brojeve od 1 do deset pomoću while petlje
         
   $broj=1;
   while($broj<=10){
    echo "<br>Broj:".$broj;
    $broj++;
   }
 echo "<p>Primjer 2</p>";
    $brojka=20;
   while($brojka>=-10){
    echo "<br>Brojka:".$brojka--;
   }

    echo "<p>Primjer 3 - continue</p>";
             
   $br=1;
   while($br<=20){
      if($br%2==1){
        $br++;
        continue;
      }
      $br++;
    echo "<br>Br:".$br++;
    }

      echo "<p>Primjer 4 - break</p>";
             
   $aa=5;
   while($aa>=-5){
  
    echo "<br>aa:".--$aa;
     if($aa==0){
        break;
     }
    
   }
     echo "<p>Primjer 5</p>";
      
     $a=1;
     $zbrojparnih=0;
     $djeljivihsatri=0;
     while ($a <= 30) {
        echo "<br>Broj a:".$a;
        if($a%2==0){
            $zbrojparnih+=$a;//zbrojparnih=zborjparnih+a;
        }
        if($a%3==0){
            $djeljivihsatri++;
        }
        $a++;
     }
     echo "<br>Zbroj parnih:".$zbrojparnih;
     echo "<br>Djeljivih sa tri:".$djeljivihsatri;

      echo "<p>Primjer 6</p>";

     echo "<p>kako treba izgledati:</p>";


?>
<table>
    <thead>
        <tr>
            <th>Broj</th>
            <th>Korijen</th>
            <th>Parnost</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>1</td>
            <td>Neparan</td>
        </tr>
           <tr>
            <td>2</td>
            <td>1.414</td>
            <td>Paran</td>
        </tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>Broj</th>
            <th>Korijen</th>
            <th>Parnost</th>
        </tr>
    </thead>
    <tbody>
       <?php 
       $brojka=1;
       while($brojka<=10){
        $korijen=round(sqrt($brojka),3);
        if($brojka%2==0){
            $parnost="Paran";
            $klasa="parni";
        }else{
            $parnost="Neparan";
            $klasa="neparni";
        }
       ?>
       <tr class="<?php echo $klasa; ?>">
        <td><?php echo $brojka; ?></td>
        <td><?php echo $korijen; ?></td>
        <td><?php echo $parnost;?></td>
       </tr>
       <?php 
         $brojka++;
       }
       ?>
    </tbody>
</table>

<?php 
   echo "<p>Primjer 7</p>";
   /** pomoću while petlje ispisati fibbonacijev niz do 800 ako su poznate  prve dvije vrijednosti
    *

    */
   $prvi=0;
   $drugi=1;
   $sljedeci=$prvi+$drugi;
   while($sljedeci<=800){
    echo $sljedeci.", ";
    $prvi = $drugi;
    $drugi=$sljedeci;
    $sljedeci=$prvi+$drugi;
   }

?>
    </body>
</html> 