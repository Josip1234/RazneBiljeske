<!DOCTYPE html>
<html lang="HR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadatak za izradu</title>
    <style>
        table {
            width: 60%;
            border-collapse: collapse;
            background-color: #fff;
            font-size: 12px;
            margin-top: 20px;
            border-style: initial;

        }

        th,
        td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
    </style>
</head>

<body>

    <h2>Kako bi tablica trebala izgledati</h2>
    <table>
        <thead>
            <tr>
                <th></th>
                <th>Matematika</th>
                <th>Programiranje</th>
                <th>Baze podataka</th>
                <th>Algoritmi</th>
                <th>Web dizajn</th>
                <th>Projek</th>
                <th>Uspjeh</th>
            </tr>
        </thead>
        <tbody>

            <tr>
                <td>Učenik br.1</td>
                <td>5</td>
                <td>4</td>
                <td>2</td>
                <td>3</td>
                <td>2</td>
                <td>3,2</td>
                <td>dobar</td>
            </tr>
            <tr>
                <td>Učenik br.2</td>
                <td>3</td>
                <td>1</td>
                <td>2</td>
                <td>2</td>
                <td>4</td>
                <td>1</td>
                <td>nedovoljan</td>
            </tr>
            <tr>
                <td>Učenik br.3</td>
                <td>4</td>
                <td>3</td>
                <td>4</td>
                <td>5</td>
                <td>3</td>
                <td>3,8</td>
                <td>vrlo dobar</td>
            </tr>
            <tr>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
                <td>...........</td>
            </tr>
            <tr>
                <td>Učenik br.10</td>
                <td>2</td>
                <td>3</td>
                <td>2
                </td>
                <td>2</td>
                <td>2</td>
                <td>2,2</td>
                <td>dovoljan</td>
            </tr>
        </tbody>
    </table>


    <h2>Konačni izgled tablice</h2>
    <?php
    require_once("izracuni.php");
    ?>
    <table>
        <thead>
            <tr>
                <th></th>
                <th>Matematika</th>
                <th>Programiranje</th>
                <th>Baze podataka</th>
                <th>Algoritmi</th>
                <th>Web dizajn</th>
                <th>Projek</th>
                <th>Uspjeh</th>
            </tr>
        </thead>
        <tbody>
            <?php

            for ($broj_ucenika = 1; $broj_ucenika <=10; $broj_ucenika++) {
                $ocjena1 = generiraj_ocjenu();
                $ocjena2 = generiraj_ocjenu();
                $ocjena3 = generiraj_ocjenu();
                $ocjena4 = generiraj_ocjenu();
                $ocjena5 = generiraj_ocjenu();
                $prosjek = izracunaj_prosjek_ocjena($ocjena1, $ocjena2, $ocjena3, $ocjena4, $ocjena5);
                $uspjeh = vrati_uspjeh_za_sljedeci_prosjek($prosjek);

                echo "<tr>";
                echo "<td>" . generiraj_ucenika($broj_ucenika) . "</td>";
                echo "<td>" . $ocjena1 . "</td>";
                echo "<td>" . $ocjena2 . "</td>";
                echo "<td>" . $ocjena3 . "</td>";
                echo "<td>" . $ocjena4 . "</td>";
                echo "<td>" . $ocjena5 . "</td>";
                echo "<td>" .  $prosjek . "</td>";
                echo "<td>" .  $uspjeh . "</td>";
                echo "</tr>";
            };
            ?>
        </tbody>
    </table>
</body>

</html>