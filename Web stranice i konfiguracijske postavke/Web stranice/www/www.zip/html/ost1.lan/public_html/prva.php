<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Josip Bošnjak</title>
</head>
<body>

<h1>Moje ime je Josip Bošnjak</h1>
<p>Živim u Požegi. Imam 32 godine. Trenutno nezaposlen. Upisao sam tečaj u Algebri. Pohađam program za stjecanje djelomične kvalifikacije
za backend developera. Nadam se da ću položiti. Želim vam svima ugodan dan!</p>
<?php echo "<h2>Važna obavijest! Položio sam orvi parcijalni ispit održanog u četvrtak prošli tjedan. Nisam dobio postotak, 
ali mislim da sam riješio negdje oko 70-80%.</h2>";  ?>

</body>
</html>
